// 기존 행을 수정하지 않고 7개 레시피 중 이름이 없는 메뉴만 추가합니다.
function appendBatch11Recipes() {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ss = SpreadsheetApp.openById('1Gj5zPymNTHPqkoc-d1dl--3hGcEK_44i63_PPPXvWeQ');
    const sheet = ss.getSheets().find(s => s.getSheetId() === 1449143922);
    if (!sheet) throw new Error('대상 탭을 찾을 수 없습니다.');
    const headers = ["레시피 ID", "음식 이름", "주재료", "재료 및 분량", "만드는 방법", "할머니 메모", "인스타 링크", "사진 URL", "분류", "조리 시간(분)", "공개 여부", "묶음", "출처", "잘 먹음"];
    const actual = sheet.getRange(1, 1, 1, 14).getDisplayValues()[0];
    if (headers.some((h, i) => h !== actual[i])) throw new Error('열 제목이 달라 중단했습니다.');
    const rows = [["", "닭안심 간장구이", "닭안심, 전분가루, 간장", "닭안심 6덩이, 전분가루 1숟가락 듬뿍, 소금 약간, 후추 약간(생략 가능), 저염 맛간장 2티스푼, 조청 1티스푼(올리고당 또는 꿀 조금으로 대체 가능), 다진 마늘 1/3티스푼, 기름(분량 확인 필요)", "1. 닭안심의 힘줄을 제거하고 물기를 뺀 뒤 먹기 좋게 잘라주세요.\n2. 소금과 후추를 조금 뿌려 버무려주세요.\n3. 전분가루를 뿌려 한 번 더 버무려주세요.\n4. 기름을 두른 팬에 노릇하게 구워주세요.\n5. 팬의 빈 공간에 소스 재료를 넣고 섞다가 끓어오르면 닭안심과 섞어주세요.\n\n💡 닭안심을 작게 자르면 굽기는 조금 번거로워도 더 맛있어요.\n💡 원작자는 후추를 생략하고 요리소금만 조금 뿌렸어요.", "", "", "https://teahill1111.github.io/recipe-box/photos/batch11-01.jpg", "반찬", "", "공개", "닭안심 간장구이·두부 김말이 스틱·새우 뭇국·옥수수 오이 탕탕이", "@danmom_shinhye", ""], ["", "두부 김말이 스틱", "두부, 김, 계란", "두부 100g, 아기김 1봉지, 저염 굴소스 또는 소금 조금, 계란(분량 확인 필요), 기름(분량 확인 필요), 전분가루 또는 부침가루(선택, 분량 확인 필요)", "1. 두부를 새끼손가락만 한 스틱 모양으로 자르고 물기를 닦아주세요.\n2. 아기김을 반으로 잘라 두부에 감싼 뒤 접합면이 아래로 가게 놓아주세요.\n3. 계란에 저염 굴소스를 조금 넣고 풀어주세요.\n4. 두부 김말이를 계란물에 담갔다가 기름을 두른 팬에 노릇하게 구워주세요.\n\n💡 두부에 전분가루나 부침가루를 먼저 묻히고 계란물을 묻히면 더 맛있어요. 원작자는 간단히 만들기 위해 생략했어요.\n💡 팬에 올릴 때도 접합면이 아래로 가게 놓아주세요.\n💡 계란은 조리법에 나오지만 원문에 분량이 기재되지 않았어요.", "", "", "https://teahill1111.github.io/recipe-box/photos/batch11-02.jpg", "반찬", "", "공개", "닭안심 간장구이·두부 김말이 스틱·새우 뭇국·옥수수 오이 탕탕이", "@danmom_shinhye", ""], ["", "새우 뭇국", "새우, 무, 대파", "무 60g, 새우 4~5마리, 대파 조금, 채소육수 또는 물 300ml, 다진 마늘 1/4티스푼, 애간장 1티스푼 또는 간장 조금, 기름(분량 확인 필요)", "1. 무를 얇게 나박썰어주세요.\n2. 냄비에 기름을 두르고 무를 약 2분 볶아주세요.\n3. 채소육수를 붓고 무가 투명해질 때까지 끓여주세요.\n4. 다진 마늘과 애간장을 넣고 끓이다가 무가 다 익으면 새우를 넣어주세요.\n5. 새우가 익으면 대파를 넣고 한 번 더 끓여주세요.\n\n💡 원문 재료명 ‘애간장’을 그대로 기록했어요.", "", "", "https://teahill1111.github.io/recipe-box/photos/batch11-03.jpg", "국·찌개", "", "공개", "닭안심 간장구이·두부 김말이 스틱·새우 뭇국·옥수수 오이 탕탕이", "@danmom_shinhye", ""], ["", "옥수수 오이 탕탕이", "오이, 옥수수", "오이 1/2개, 옥수수 2숟가락, 참기름 조금, 깨 조금, 저염 굴소스 1/2티스푼 또는 저염 간장 조금", "1. 오이를 두드려 결대로 깨지게 한 뒤 씨 부분을 제거해주세요.\n2. 먹기 좋은 조각으로 잘라주세요.\n3. 나머지 재료를 모두 넣고 섞어주세요.\n\n💡 봉지에서 버무려도 되고 접시로 옮겨 담아 섞어도 돼요.\n💡 원작자는 다음 날까지 냉장했을 때도 괜찮았지만 되도록 바로 먹을 양만 만들기를 권했어요.", "", "", "https://teahill1111.github.io/recipe-box/photos/batch11-04.jpg", "반찬", "", "공개", "닭안심 간장구이·두부 김말이 스틱·새우 뭇국·옥수수 오이 탕탕이", "@danmom_shinhye", ""], ["", "소고기떡조림", "소고기, 조랭이떡", "소고기 다짐육 100g, 조랭이떡 100g, 불고기소스 1스푼, 쌀조청 1스푼, 참기름 1스푼, 다진 마늘 약간, 기름(분량 확인 필요)", "1. 소고기에 불고기소스, 쌀조청, 참기름, 다진 마늘을 넣고 섞어주세요.\n2. 기름을 두른 팬에 양념한 소고기를 넣고 볶아주세요.\n3. 소고기가 익으면 조랭이떡을 넣고 섞어주세요.\n4. 조랭이떡이 말랑말랑해질 때까지 익혀주세요.\n\n💡 불고기소스가 없으면 아기간장으로 대체해주세요.\n💡 원작자는 불고기소스, 쌀조청, 굴소스, 참기름으로 다온 제품을 사용했어요.", "", "", "https://teahill1111.github.io/recipe-box/photos/batch11-05.jpg", "반찬", "", "공개", "유아식반찬 레시피모음 82탄", "@ddohuni_mom", ""], ["", "새우팽이버섯볶음", "새우, 팽이버섯, 버터", "새우 6마리(100g), 팽이버섯 1/2봉, 무염버터 10g, 굴소스 1티스푼", "1. 새우를 먹기 좋은 크기로 자르고 팽이버섯은 잘게 썰어주세요.\n2. 버터를 녹인 팬에 새우를 넣고 볶아주세요.\n3. 새우가 익어갈 때 팽이버섯을 넣고 함께 볶아주세요.\n4. 굴소스를 넣고 완전히 익을 때까지 골고루 볶아주세요.\n\n💡 원작자는 굴소스로 다온 제품을 사용했어요.", "", "", "https://teahill1111.github.io/recipe-box/photos/batch11-06.jpg", "반찬", "", "공개", "유아식반찬 레시피모음 82탄", "@ddohuni_mom", ""], ["", "당근전", "당근, 전분가루", "당근 1/2개, 전분가루 1스푼, 기름(분량 확인 필요), 무염버터(기름 대신 선택, 분량 확인 필요)", "1. 채칼을 활용해 당근을 얇게 채 썰어주세요.\n2. 채 썬 당근에 전분가루를 넣고 골고루 섞어주세요.\n3. 기름을 두른 팬에 반죽을 올려 앞뒤로 노릇하게 구워주세요.\n\n💡 무염버터로 구우면 더 맛있어요.", "", "", "https://teahill1111.github.io/recipe-box/photos/batch11-07.jpg", "반찬", "", "공개", "유아식반찬 레시피모음 82탄", "@ddohuni_mom", ""]];
    const names = new Set(sheet.getRange(1, 2, Math.max(1, sheet.getLastRow()), 1).getDisplayValues().flat().map(x => x.trim()));
    const missing = rows.filter(r => !names.has(r[1].trim()));
    if (!missing.length) { ss.toast('이미 모두 입력되어 있습니다.'); return; }
    const start = sheet.getLastRow() + 1;
    const end = start + missing.length - 1;
    if (end > sheet.getMaxRows()) sheet.insertRowsAfter(sheet.getMaxRows(), end - sheet.getMaxRows());
    const range = sheet.getRange(start, 1, missing.length, 14);
    range.setValues(missing);
    sheet.getRange(start, 5, missing.length, 1).setWrap(true);
    SpreadsheetApp.flush();
    const saved = range.getValues();
    if (missing.some((r,i) => r.some((v,j) => String(v) !== String(saved[i][j])))) throw new Error('입력 후 검증 실패: 중복 실행하지 말고 새 행을 확인해주세요.');
    ss.toast(missing.length + '개 추가 완료: A' + start + ':N' + end);
  } finally { lock.releaseLock(); }
}
